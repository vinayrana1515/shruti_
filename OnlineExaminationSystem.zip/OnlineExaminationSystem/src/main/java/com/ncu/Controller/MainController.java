package com.ncu.Controller;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ncu.Model.ExamDetails;
import com.ncu.Model.FacultyDetails;
import com.ncu.Model.Question;
import com.ncu.Model.StudentDetails;
import com.ncu.Model.UserLogin;
import com.ncu.Model.UserLoginCheck;
import com.ncu.dao.FacultyDetailsDao;
import com.ncu.dao.LoginCheckDao;
import com.ncu.dao.StudentDetailsDao;


@Controller
public class MainController {
	private LoginCheckDao lcd;
	private FacultyDetailsDao fdd;
	private StudentDetailsDao sdd;
	
	@RequestMapping("/home")
	public String home() {
		return "home";
	}


	@RequestMapping("/register")
	public String userRegistration(Model model) {
		model.addAttribute("UserModel", new UserLogin());
		return "register";
	}
	@RequestMapping("/login")                       // admin login after home page
	public String userLogin(Model model) {
	    model.addAttribute("UserModel", new UserLoginCheck());
			
		return "login";
	}
	
	@RequestMapping("/admin") // after pressing admin login checking for id and password
	public String admin(@ModelAttribute("UserAdmin") UserLoginCheck ulc,Model model) {
	
		// lcd.getAdmin(ulc.getEmail(), ulc.getPassword()); // if this true then 
		
		return "admin";
		
		 // else return "login";
		
		
	}

	
	@RequestMapping("/loginFaculty") // faculty login after home page
	public String facultyLogin(Model fl) {
		fl.addAttribute("UserModel", new UserLoginCheck());
		return "loginFaculty";
	}
	
	@RequestMapping("/faculty") // after pressing login checking
	public String faculty(@ModelAttribute("UserAdmin") UserLoginCheck ulc,Model model) {
		
		// lcd.getFaculty(ulc.getEmail(), ulc.getPassword()); // if this true then 
		return "faculty";
		
		// else return "loginFaculty";
	}
	
	
	@RequestMapping("/loginStudent") // student login after home page
	public String studentLogin(Model sl) {
		sl.addAttribute("UserModel", new UserLoginCheck());
		
		return "loginStudent";
	}
	
	@RequestMapping("/student") // login check for student 
	public String student(@ModelAttribute("UserAdmin") UserLoginCheck ulc,Model model) {
	 //lcd.getStudent(ulc.getEmail(), ulc.getPassword());
	
		return "student"; //if true
		
		// else return "loginStudent"
	}
	
	
	/*
	 * @RequestMapping("/login") public String userLogin(Model model) {
	 * model.addAttribute("UserModel", new UserLogin()); return "login"; }
	 */
	  @RequestMapping("/fmanage") 
	  public String facultyManage(@ModelAttribute("UserModel") FacultyDetails fd, Model model) {
		  
		//  List<FacultyDetails> flist=fdd.getAllFaculties();
		 //model.addAttribute("flist",flist); 
		  return "faculty_manage"; 
	 }
	
	  @RequestMapping("/addFaculty")
		public String addFaculty(@ModelAttribute("UserModel") FacultyDetails fd, Model model2) {
			
//			 try
//		        {
//		            if(fdd.getFacultyByEmail(fd.getEmail()) != null);
//		            fdd.updateFaculty(fd); // print error email already present 
//		        }
//		        catch(EmptyResultDataAccessException e)
//		        {
//		            System.out.println("inside catch");
//		            fdd.saveFaculty(fd);
//		        }
//		        return ("redirect:/faculty_manage");
//		    }
			return "add_faculty";
		}
		
	
	@RequestMapping("/smanage")
	public String studentManage(@ModelAttribute("UserModel") StudentDetails sd,Model model) {
//		List<StudentDetails> slist=sdd.getAllStudents();
//		model.addAttribute("slist", slist);
		
		return "student_manage";
	}
	 
	
	@RequestMapping("/addStudent")
	public String addStudent(@ModelAttribute("UserModel") StudentDetails sd,Model model1) {
		
		
//		 try
//	        {
//	            if(sdd.getStudentByEmail(sd.getEmail()) != null);
//	            sdd.updateStudent(sd); // print error email already present 
//	        }
//	        catch(EmptyResultDataAccessException e)
//	        {
//	            System.out.println("inside catch");
//	            sdd.saveStudent(sd);
//	        }
//	        return ("redirect:/student_manage");
//	    }
		
		
		return "add_student";
	}
	
	
	  
	  @RequestMapping("/examDetails") 
	  public String examDetails(Model model) {
		  model.addAttribute("ExamModel", new ExamDetails());
		  return "examDetails"; 
	 }
	  @RequestMapping("/examlist") 
	  public String examList() {
		  return "examlist"; 
	 }
	  @RequestMapping("/viewExam") 
	  public String viewExam() {
		  return "viewExam"; 
	 }
	  @RequestMapping("/newQues") 
	  public String newQues(Model m) {
		  m.addAttribute("QuesModel", new Question());
	  
		  return "newQues"; 
	 }
	
	  
	/*
	 * @RequestMapping("/Fmanage") public String facultyManage(@ModelAttribute
	 * ("UserModel") UserLogin user, Model model ) { model.addAttribute("Name",
	 * user.getUsername()); model.addAttribute("Email", user.getEmail());
	 * model.addAttribute("Password", user.getPassword());
	 * model.addAttribute("Date of Birth", user.getDob());
	 * 
	 * 
	 * return "faculty_manage"; }
	 */

}