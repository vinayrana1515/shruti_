package com.ncu.dao;

public interface LoginCheckDao {
	
public String getAdmin(String email,String password);
public String getFaculty(String email,String password);
public String getStudent(String email,String password);
}
