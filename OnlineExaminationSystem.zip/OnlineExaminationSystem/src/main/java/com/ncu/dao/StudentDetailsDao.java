package com.ncu.dao;

import java.util.List;


import com.ncu.Model.StudentDetails;

public interface StudentDetailsDao {
	public StudentDetails getStudentByEmail(String email);
	public List<StudentDetails> getAllStudents();
	public void deleteStudent(String email);
	public void updateStudent(StudentDetails sd);
	public void saveStudent(StudentDetails sd);
}
