package com.ncu.dao;

import java.util.List;

import com.ncu.Model.FacultyDetails;

public class FacultyDetailsDaoImpl implements FacultyDetailsDao {

	@Override
	public List<FacultyDetails> getAllFaculties() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteFaculty(String email) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateFaculty(FacultyDetails fd) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void saveFaculty(FacultyDetails fd) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public FacultyDetails getFacultyByEmail(String email) {
		// TODO Auto-generated method stub
		return null;
	}

}
