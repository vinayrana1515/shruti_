package com.ncu.dao;

public class LoginCheckDaoImpl implements LoginCheckDao {



	@Override
	public String getAdmin(String email, String password) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFaculty(String email, String password) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getStudent(String email, String password) {
		// TODO Auto-generated method stub
		return null;
	}

}
