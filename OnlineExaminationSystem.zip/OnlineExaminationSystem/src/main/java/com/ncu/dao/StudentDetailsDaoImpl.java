package com.ncu.dao;

import java.util.List;

import com.ncu.Model.StudentDetails;

public class StudentDetailsDaoImpl implements StudentDetailsDao{

	@Override
	public StudentDetails getStudentByEmail(String email) {
		// TODO Auto-generated method stub
		return null;
	}




	@Override
	public List<StudentDetails> getAllStudents() {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public void deleteStudent(String email) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void updateStudent(StudentDetails sd) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void saveStudent(StudentDetails sd) {
		// TODO Auto-generated method stub
		
	}

}
