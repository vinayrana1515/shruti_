package com.ncu.dao;
import java.util.List;

import com.ncu.Model.FacultyDetails;

public interface FacultyDetailsDao {
	public FacultyDetails getFacultyByEmail(String email);
	public List<FacultyDetails> getAllFaculties();
	public void deleteFaculty(String email);
	public void updateFaculty(FacultyDetails fd);
	public void saveFaculty(FacultyDetails fd);
}
